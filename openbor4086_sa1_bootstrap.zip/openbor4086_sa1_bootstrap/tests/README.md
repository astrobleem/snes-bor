# Test strategy

`gate0_program.json` is the mandatory first acceptance gate. It is deliberately small
and integer-only. Constants are preinitialized and their `CONSTINT` records are runtime
no-ops, matching the linked interpreter model.

The expected trace proves all of these independently:

- sequential IP increment;
- `ADD` writes the declared destination slot;
- `EQ` writes INTEGER 1;
- `Branch_FALSE` does not branch on a true value;
- `JUMP` assigns IP without a second increment;
- the unreachable `ERR` remains unreachable; and
- root `RET` reports DONE.

Place guard patterns before and after the slot region, frame region, and trace region.
A Gate 0 run fails if any guard byte changes.

After Gate 0, generate one fixture per semantic family rather than one giant script.
Always compare full typed slot values, IP trace, call/native trace, and fault cells.

## Packed fixture files

- `gate0_module.bin` is a revision-1 module ready for ROM inclusion or emulator loading.
- `gate0_expected_slots.bin` is the exact 40-byte final slot region expected after DONE.
- Run `python3 tools/run_gate0_reference.py` to validate the JSON semantics.
- Run `python3 tools/verify_manifest.py` to validate opcode numbering and fixture names.

The CRC32 stored in the module header covers bytes `$40..end`.
