# Research anchors and confidence notes

## Historical OpenBOR semantic anchor

Repository: `DCurrent/openbor`

Snapshot used for the old 48-slot ABI and value/runtime semantics:
`29869a3267f812ea6dc069541029998c3306e4fb`

Relevant paths:

- `engine/source/scriptlib/Instruction.h`
- `engine/source/scriptlib/Instruction.c`
- `engine/source/scriptlib/Interpreter.c`
- `engine/source/scriptlib/ScriptVariant.h`
- `engine/source/scriptlib/ScriptVariant.c`

This is a close historical source anchor. It is **not claimed to be an exact mapping of
OpenBOR binary Build 4086**. Before preserving a bug or edge case, run the exact Build
4086 executable/source as an oracle.

The modern `BIT_NOT` opcode is outside the target ABI. Its later runtime emission was
introduced in repository commit `d2e8e664721514b0d8f14f0d7c830b57a088efc6`
(June 8, 2026).

## SA-1 architecture anchor

Repository: `astrobleem/supermn-snes`

Relevant paths:

- `README.md`
- `src/interp.pasm`
- `docs/toolchain/README.md`
- `docs/toolchain/MC68000_INTERPRETER.md`
- `docs/toolchain/DEBUGGING.md`
- `docs/toolchain/SCHEDULER_TIMING.md`
- `tools/build_interp.sh`

Transferable patterns:

- explicit SA-1 IRAM initialization;
- direct-page hot state;
- bulk state in BW-RAM;
- correctness-first interpretation;
- deterministic trace/fault state;
- explicit device/CPU ownership boundaries;
- host-oracle differential fixtures; and
- native escapes only after measured hot-path identification.

Do not copy game-specific Superman bank addresses, IRQ cadence, emulator assumptions,
or ROM mappings into the BOR VM without adapting them.
