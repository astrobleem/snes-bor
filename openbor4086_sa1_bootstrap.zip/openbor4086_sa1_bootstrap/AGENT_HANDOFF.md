# Copy-ready agent handoff

You are implementing the OpenBOR/Beats of Rage **Build 4086-era script opcode VM** in
65816 assembly for the SNES SA-1.

Read, in order:

1. `README.md`
2. `FORMAT.md`
3. `opcode_manifest.csv`
4. `src/bor_vm_opcodes.pasm`
5. `src/bor_vm_core.pasm`
6. `tests/gate0_program.json`

## Scope

Implement a correctness-first, linked-slot interpreter. Do not port the OpenBOR parser,
linked lists, allocator, or raw C pointers to the cartridge. A host exporter will resolve
symbols, labels, values, calls, and strings into numeric IDs and serialize fixed records.

The ABI has opcode values 0..47. `OPCODE_END=48` is a sentinel. `FIELD=7` is a dead
historical slot and must fault. There is no `BIT_NOT` in this target ABI.

Use the architecture patterns from `astrobleem/supermn-snes`:

- hot VM state in SA-1 IRAM/direct page;
- explicit IRAM clear at cold boot;
- bulk mutable state in BW-RAM;
- fixed-width state and no runtime allocation;
- explicit SA-1/5A22 mailbox ownership;
- trace/freeze state for faults;
- interpreter first, native hot-path escapes only after measured correctness.

## First task only

Make `tests/gate0_program.json` run and match its expected final state. That requires:

- loading and validating the module fixture;
- fetching eight-byte records;
- decoding A/B/C;
- dispatching by the exact opcode number;
- slot address calculation and eight-byte slot copy;
- signed 32-bit integer ADD;
- integer EQ producing `VT_INTEGER` 0 or 1;
- `Branch_FALSE`, `JUMP`, `ERR`, and root `RET`;
- deterministic bad-opcode and bad-slot faults;
- a short `(IP, opcode)` trace ring.

Do not add calls, strings, decimals, native OpenBOR functions, or dispatcher optimization
before Gate 0 passes.

## Gate 0 evidence to return

Return these artifacts with the implementation:

- assembled ROM or test binary;
- symbol file;
- exact source commit/hash;
- initial and final slot dump;
- executed IP/opcode trace;
- VM status/error cells;
- guard bytes surrounding all BW-RAM VM regions; and
- host-side command that verifies the result against `gate0_program.json`.

## Non-negotiable semantic decisions

- Unknown opcode: fault, never no-op.
- `FIELD`: `VMERR_FIELD_OPCODE`.
- Sequential handlers increment IP exactly once.
- Branch/call/return handlers assign IP and do not fall through to a second increment.
- INTEGER is signed 32-bit; helpers operate on two 16-bit words.
- Numeric comparison yields INTEGER 0/1.
- Slot IDs, instruction indices, callsite IDs, string handles, and native IDs are all
  range checked before use.
- Every externally reachable assembly entry explicitly establishes A/X width.

## Research anchors

Use these as semantic and architectural references, not as a license to assume exact
Build 4086 quirks without fixtures:

- `DCurrent/openbor`, historical commit `29869a3267f812ea6dc069541029998c3306e4fb`
  - `engine/source/scriptlib/Instruction.h`
  - `engine/source/scriptlib/Instruction.c`
  - `engine/source/scriptlib/Interpreter.c`
  - `engine/source/scriptlib/ScriptVariant.h`
  - `engine/source/scriptlib/ScriptVariant.c`
- `DCurrent/openbor`, commit `d2e8e664721514b0d8f14f0d7c830b57a088efc6`
  documents the much later addition of `BIT_NOT`.
- `astrobleem/supermn-snes`
  - `src/interp.pasm`
  - `docs/toolchain/MC68000_INTERPRETER.md`
  - `docs/toolchain/DEBUGGING.md`
  - `docs/toolchain/SCHEDULER_TIMING.md`

Stop after Gate 0 evidence is green. Do not proceed to Gate 1 in the same change.
