# OpenBOR Build 4086 Script VM on SNES SA-1

## Bootstrap package for a 65816 implementation agent

This package is a design contract, opcode manifest, serialization format, test gate,
and Poppy-style 65816 scaffold for implementing the **OpenBOR/Beats of Rage Build
4086-era script interpreter on the SNES SA-1**.

It is deliberately modeled as a **linked slot VM**, not as a port of the OpenBOR parser,
linked lists, `malloc()`, or host pointers. A host tool parses and links scripts, assigns
stable numeric IDs to every instruction value/reference, resolves labels and calls, and
emits a compact ROM image. The SA-1 executes only the already-linked runtime graph.

The inspiration is `astrobleem/supermn-snes`: keep hot interpreter state in SA-1
IRAM/direct page, keep bulk mutable state in BW-RAM, access hardware through explicit
boundaries, begin with a correctness-first interpreter, and replace measured hot paths
with native 65816 only after the interpreter agrees with an independent oracle.

---

## 1. Facts that are already settled

1. The old ABI has **48 numbered opcode slots, values 0 through 47**.
2. `OPCODE_END` is the sentinel value 48 and is not executable.
3. `BIT_NOT` is **not** part of the Build 4086-era ABI. It was added much later.
4. Opcode 7, `FIELD`, appears in the enum and debug formatter but has no case in the
   historical compile switch or runtime switch. Treat it as a deterministic fault.
5. Several opcode records are consumed by the host linker and become runtime no-ops.
   Do not waste SA-1 cycles recreating the old compiler's linked-list behavior.
6. Build-era values are `EMPTY`, signed 32-bit `INTEGER`, binary64 `DECIMAL`, `PTR`,
   and `STR`. A fixed-point decimal profile is practical on SA-1 but is not bit-exact.
7. Exact Build 4086 edge behavior must be established with oracle fixtures. The source
   anchor used here is a close historical OpenBOR snapshot, not a proven byte-for-byte
   identification of SVN/build revision 4086.

### First acceptance gate

Do **not** begin with all 48 handlers, native OpenBOR functions, strings, or decimals.
The first accepted milestone is the included `tests/gate0_program.json`:

- load preinitialized integer constants;
- perform `ADD` and `EQ`;
- take the correct conditional branch;
- return with the expected slot image; and
- produce no writes outside the declared VM regions.

Only after that fixture matches the host oracle should the agent add the next semantic
family. `tests/gate0_module.bin` is a packed module for direct inclusion, and
`tests/gate0_expected_slots.bin` is the exact expected final slot image.

---

## 2. Deliverable architecture

```text
Host build machine                         SNES cartridge
------------------                         --------------
OpenBOR-era parser/compiler or extractor   ROM: module header
        |                                  ROM: 8-byte instruction records
        v                                  ROM: initial variant slots
Linked Instruction graph                   ROM: interned strings / call metadata
        |                                  BW-RAM: mutable slots / frames / strings
        v                                  SA-1 IRAM/DP: IP, operands, status, trace
bor4086 exporter                            SA-1: opcode interpreter + native calls
        |                                  5A22: VBlank, PPU/APU, controller supervisor
        +---------- binary module --------> command/result rings between CPUs
```

### Why linked slots

The historical OpenBOR runtime does not reevaluate an expression stack every time an
instruction executes. Its compile pass caches `ScriptVariant*` references on each
instruction. At runtime, `LOAD`, `SAVE`, unary operations, binary operations, branches,
and calls operate on those cached references. Numeric slot IDs preserve this structure
without preserving unsafe host addresses.

The exporter must therefore map:

- every persistent or instruction-owned `ScriptVariant` object to a slot ID;
- every jump target to an instruction index;
- every script function entry to an instruction index;
- every native function pointer to a stable native function ID;
- every call's ordered argument references to a callsite side-table entry; and
- every string to a ROM-interned handle or an initialized dynamic-string object.

---

## 3. Cartridge memory ownership

The exact banks are project configuration. The ownership rules are not.

| Region | Owner and contents |
|---|---|
| SA-1 IRAM/direct page | Hot VM state, current record, temporary 32-bit operands, call-stack top, fault record, short trace ring |
| BW-RAM | Mutable variant slots, call frames, dynamic-string pool, native-call argument/result rings |
| ROM | Module header, instruction records, callsite metadata, initial slot image, interned strings, native ID table |
| 5A22 WRAM | PPU staging, DMA queues, controller state, audio supervision; never used as SA-1's implicit VM heap |

At SA-1 reset, explicitly clear every IRAM byte used by the VM. Do not rely on emulator
power-on contents. Set accumulator/index widths explicitly at every externally reachable
entry point.

### Suggested direct-page cells

```text
$00-$01  VM_IP                 instruction index within current module
$02-$03  VM_STATUS             READY/RUNNING/YIELDED/DONE/FAULT
$04-$06  VM_CODE_PTR           24-bit base pointer to instruction records
$08-$0A  VM_SLOT_PTR           24-bit base pointer to mutable slots
$0C       VM_OPCODE
$0D       VM_FLAGS
$0E-$0F  VM_A                  decoded record operand A
$10-$11  VM_B                  decoded record operand B
$12-$13  VM_C                  decoded record operand C
$14-$17  VM_TMP0               32-bit scratch
$18-$1B  VM_TMP1               32-bit scratch
$1C-$1F  VM_TMP2               32-bit scratch
$20-$21  VM_FRAME_TOP          byte offset or frame index
$22-$23  VM_BUDGET             opcodes remaining before cooperative yield
$24-$25  VM_ERROR              deterministic fault code
$26-$27  VM_ERROR_IP           failing instruction index
$28       VM_ERROR_OPCODE      failing opcode
$30-$6F  implementation scratch / helper arguments
$80-$FF  compact trace ring or additional project-reserved state
```

Use a separate 65816 hardware stack in the remaining IRAM. Do not let it collide with
DP, the trace ring, or cross-CPU mailbox cells.

---

## 4. Serialized instruction format

Every normalized instruction is eight bytes:

```c
struct Bor4086Instruction {
    uint8_t  opcode;   // exact old ABI value 0..47
    uint8_t  flags;    // exporter/VM flags; zero for the base profile
    uint16_t a;        // little-endian operand A
    uint16_t b;        // little-endian operand B
    uint16_t c;        // little-endian operand C
};
```

The SNES format is little-endian because the 65816 consumes it directly. The host
exporter is responsible for converting OpenBOR host structures into this format.

A module is initially limited to **8192 records**, keeping the record array within one
64 KiB address window. Larger scripts should be split into modules or move to a 24-bit
record-PC format only after the base implementation works.

See `FORMAT.md` for the module header, slot formats, callsite table, and native table.

---

## 5. Variant representation

### Practical SA-1 profile: eight-byte slots

```c
struct BorVariant8 {
    uint8_t  type;      // 0 EMPTY, 1 INTEGER, 2 DECIMAL_Q16_16, 5 PTR, 6 STR
    uint8_t  flags;     // ownership, read-only, engine-handle kind
    uint16_t aux;       // string length/refcount metadata or handle subtype
    uint32_t value;     // integer, Q16.16, typed handle, or string handle
};
```

This profile keeps the historical type numbers while representing decimal values as
signed Q16.16. It is fast and compact, but not binary64-compatible. The exporter must
stamp the module as `numeric_profile = Q16_16`, and the test oracle must quantize expected
results the same way.

### Strict profile: twelve-byte slots

```c
struct BorVariant12 {
    uint8_t  type;
    uint8_t  flags;
    uint16_t aux;
    uint64_t value;
};
```

Use this only when exact binary64 behavior is required. The interpreter then needs
software conversion, arithmetic, and comparisons for `double`. Do not pretend Q16.16
passes a binary64 differential test.

### Pointer rule

`VT_PTR` is a typed engine handle, never a raw build-machine pointer. Recommended value:

```text
bits 31..24  handle class
bits 23..0   object index or cartridge address token
```

Native calls validate the class and resolve it through the engine adapter.

### String rule

- Constant strings are interned in ROM.
- Mutable/concatenated strings live in a bounded BW-RAM pool.
- A string slot stores a handle, not an inline C pointer.
- Copying a dynamic string increments its reference count; clearing/retyping decrements it.
- Overflow, invalid handle, exhausted pool, or concatenation beyond the configured limit
  is a deterministic VM fault. Never scribble past a buffer to reproduce old C behavior.

---

## 6. Value semantics to implement

### Truthiness

| Type | False when |
|---|---|
| `VT_EMPTY` | always |
| `VT_INTEGER` | value is zero |
| `VT_DECIMAL` | value is zero |
| `VT_PTR` | handle is zero/null |
| `VT_STR` | string length is zero |

### Numeric conversion

- INTEGER to decimal: exact conversion into the selected decimal profile.
- DECIMAL to integer: truncate toward zero.
- Other types do not numerically convert; the result becomes `EMPTY` unless the opcode
  is explicitly string or pointer aware.

### Arithmetic

- `ADD`, `SUB`, `MUL`, `DIV`: if both operands are numeric, produce DECIMAL when either
  input is decimal; otherwise produce signed 32-bit INTEGER.
- `ADD`: if either input is a string, concatenate each operand's script string form.
- `DIV` by zero: historical source clears the result to EMPTY. Preserve that unless an
  exact Build 4086 oracle proves otherwise.
- `MOD`: integer-convert both operands. A zero divisor must produce `VMERR_DIV_ZERO`.
- Define integer overflow as two's-complement 32-bit wrap in the cartridge VM. Record
  any oracle difference rather than leaving 65816 helper behavior accidental.

### Bitwise and shifts

- `BIT_OR`, `XOR`, `BIT_AND`: integer-convert both operands, then operate on 32 bits.
- `SHL` and `SHR` are unsigned logical shifts of the 32-bit bit pattern.
- Normalize the shift count with `count & 31` in the base cartridge profile. Mark this
  as a compatibility decision and test counts `-1, 0, 31, 32, 33` against the oracle.

### Comparisons

- Numeric pairs compare numerically across INTEGER/DECIMAL.
- String pairs compare lexicographically by bytes.
- Pointer pairs compare their handle values.
- EMPTY equals EMPTY; ordering comparisons involving EMPTY are false.
- Different nonnumeric types compare unequal in the cartridge profile.

The old C source falls back to raw `memcmp()` for some mixed-type comparisons. That is
not a stable portable language contract because padding and representation leak into
results. Reject or normalize such scripts during export unless the exact game depends
on the behavior and an oracle fixture defines it.

### Historical quirks requiring explicit fixtures

1. The close historical source for `NEG` appears to fall through from DECIMAL to INTEGER
   handling. Test Build 4086 before deciding whether to reproduce or fix it.
2. Historical string `NE` stores the raw nonzero result of `strcmp()` rather than an
   obviously normalized Boolean. Test whether scripts observe the numeric result.
3. C shifts outside 0..31 and signed overflow are undefined at the language level.
4. Historical `MOD` has no zero-divisor guard.
5. Decimal-to-string formatting used host `printf` behavior. Define cartridge formatting
   exactly and include it in string-concatenation fixtures.

---

## 7. Call model

Replace recursive C interpreter calls with a fixed BW-RAM call-frame stack.

```c
struct BorCallFrame {
    uint16_t return_ip;
    uint16_t caller_result_slot;
    uint16_t callsite_id;
    uint16_t arg_cursor;
    uint16_t return_source_slot;  // 0xFFFF until JUMPR stages a value
    uint16_t reserved;
};
```

### `CALL`

1. Read the callsite metadata referenced by operand `c`.
2. For a script target, push a frame, set `return_ip = IP + 1`, reset `arg_cursor`, and
   jump to the script entry in operand `a`.
3. For a native target, validate every argument slot, call the native adapter, write the
   result to operand `b`, and continue at `IP + 1`.
4. On stack overflow, fault with `VMERR_CALL_DEPTH`.

### `PARAM`

Copy the argument slot at the active callsite's current cursor into destination slot `a`,
then increment the cursor. If the cursor is beyond `argc`, clear destination to EMPTY.

### `JUMPR`

Store operand `b` as the active frame's return source and set IP to epilogue target `a`.

### `RET`

If a frame exists, copy the staged return source into the caller result slot, pop the
frame, and resume at `return_ip`. Without a frame, mark the root invocation DONE.

### Native-call ABI

Keep native function IDs stable and generated by the host build. One practical 65816
contract is:

```text
Input DP cells:
  VM_NATIVE_ID       u16
  VM_CALLSITE_ID     u16
  VM_NATIVE_RESULT   u16 slot ID
  VM_ARG_COUNT       u16

Return:
  Carry clear        success; result slot initialized
  Carry set          failure; A = VM error code

Preservation:
  Native routine preserves D, DBR, and the VM's hardware-stack contract.
  A/X/Y and scratch DP cells are caller-saved.
```

All PPU/APU/controller-facing native calls publish bounded commands to the 5A22-owned
mailboxes. They do not directly perform arbitrary PPU writes from the SA-1 interpreter.

---

## 8. Dispatch and execution loop

The included `src/bor_vm_core.pasm` uses a deliberately boring compare-and-jump chain.
That mirrors the safe early style in `supermn-snes`, avoids depending on assembler-specific
jump-table syntax, and makes every ABI value visible during bring-up.

After correctness is established, a same-bank 48-entry handler-address table can replace
the chain. Do not optimize the dispatcher before opcode fixtures pass.

Each interpreter iteration:

1. checks the cooperative opcode budget;
2. computes `record = code_base + IP * 8`;
3. fetches `opcode`, `flags`, `a`, `b`, and `c`;
4. writes the current record to the trace ring;
5. validates opcode `< 48`;
6. dispatches to a handler;
7. handler either advances IP, sets a target IP, calls/returns, yields, completes, or faults.

Every handler has one exit contract:

```text
normal sequential instruction -> JMP vm_next
control transfer              -> JMP vm_run
fault                         -> JMP vm_fault
cooperative boundary          -> JMP vm_yield
root return                    -> JMP vm_done
```

This prevents accidental double increments after branches and calls.

---

## 9. Deterministic fault model

Recommended error values:

```text
$0001 VMERR_BAD_OPCODE
$0002 VMERR_FIELD_OPCODE
$0003 VMERR_EXPLICIT_ERR
$0004 VMERR_BAD_SLOT
$0005 VMERR_BAD_TYPE
$0006 VMERR_DIV_ZERO
$0007 VMERR_CALL_DEPTH
$0008 VMERR_NO_CALL_FRAME
$0009 VMERR_BAD_CALLSITE
$000A VMERR_BAD_NATIVE
$000B VMERR_STRING_POOL
$000C VMERR_STRING_OVERFLOW
$000D VMERR_BAD_JUMP
$000E VMERR_BAD_MODULE
$000F VMERR_BUDGET_PROTOCOL
```

On fault, preserve:

- failing IP and opcode;
- operands A/B/C;
- VM status and error code;
- current frame depth;
- last 16 or 32 `(IP, opcode)` entries; and
- a checksum or generation number for the loaded module.

Never turn an unimplemented handler into a no-op. A plausible but wrong script state is
harder to debug than an immediate deterministic stop.

---

## 10. Implementation sequence and gates

### Gate 0 — fetch, dispatch, integer slots, branch, root RET

Implement only what `tests/gate0_program.json` requires:

- module validation and initialization;
- slot address calculation and slot copy;
- `CONSTINT` as a prelinked no-op;
- `ADD`, `EQ`, `Branch_FALSE`, `JUMP`, `ERR`, and root `RET`;
- trace and deterministic fault state.

**Pass condition:** final slot image and status exactly match the JSON fixture.

### Gate 1 — complete control/no-op family

Implement `FIELD` trap, `PJUMP`, `Branch_TRUE`, `Branch_EQUAL`, `NOOP`, `DATA`,
`IMMEDIATE`, `DEFERRED`, `CHECKARG`, `CLEAN`, `PUSH`, `POP`, and `FUNCDECL`.

**Pass condition:** every ABI number 0..47 reaches its intended handler or explicit fault.

### Gate 2 — integer unary/binary family

Implement `LOAD`, `SAVE`, `INC`, `DEC`, `POS`, `NEG`, `NOT`, arithmetic, logical,
bitwise, shifts, and integer comparisons.

**Pass condition:** generated edge vectors match the host oracle for ordinary 32-bit
inputs, with documented decisions for overflow and shift counts.

### Gate 3 — calls

Implement script `CALL`, `PARAM`, `JUMPR`, `RET`, nested frames, missing parameters,
return values, and call-depth errors. Add a tiny native function table containing only
`abs`, `min`, `max`, and a test logging function.

**Pass condition:** nested and recursive fixture scripts match the oracle and never
corrupt adjacent BW-RAM sentinels.

### Gate 4 — strings and pointers

Implement interned strings, dynamic strings, copy/refcount, concatenation, truthiness,
comparison, and typed engine handles.

**Pass condition:** repeated calls do not leak handles, exhaust the pool, or produce
nondeterministic comparison results.

### Gate 5 — decimals

Choose and stamp one profile: Q16.16 or strict binary64. Implement conversion,
arithmetic, comparison, truth, and formatting as a coherent profile.

**Pass condition:** profile-specific differential vectors pass. Do not compare Q16.16
output against unquantized binary64 expectations.

### Gate 6 — real OpenBOR script and scheduler integration

Export one small real script from the target game, execute it on SA-1, compare its slot
and engine-call trace against a host Build 4086 oracle, then integrate cooperative yields
with the 5A22 supervisor.

**Pass condition:** the real script reaches the same native calls in the same order with
the same normalized arguments and results.

### Gate 7 — performance work

Profile organic gameplay. Only then replace measured hot native functions or script
regions with native 65816 escapes sharing the same slot/call ABI.

---

## 11. Required host-side tools

The agent should produce these before claiming broad compatibility:

1. `export_bor4086_module` — emits this package's binary format from a linked instruction
   graph or a stable intermediate dump.
2. `dump_bor4086_oracle` — runs a function/script on the host interpreter and records
   initial/final slots, branch trace, calls, returns, and fault state.
3. `compare_vm_trace` — compares host and SA-1 traces at instruction boundaries.
4. `verify_module` — checks counts, ranges, target IDs, slot IDs, callsite argument lists,
   string handles, and checksum before ROM assembly.
5. `make_opcode_vectors` — emits focused fixtures for every semantic family.

Never serialize `Instruction*`, `ScriptVariant*`, function pointers, linked-list nodes,
or host struct padding.

---

## 12. Agent completion definition

The work is not complete merely because every handler label exists. It is complete when:

- opcode ABI values 0..47 are locked by generated constants and a manifest test;
- `FIELD` and unknown values fault deterministically;
- every record and side-table reference is bounds checked;
- Gate 0 through the declared compatibility gate pass on emulator;
- the exact numeric profile is stamped in the module;
- native calls use stable IDs and typed handles;
- SA-1 IRAM is explicitly initialized;
- the 5A22/SA-1 ownership boundary is documented and enforced;
- traces can identify the last executed records after any fault; and
- performance changes preserve an interpreter-only correctness fallback.

Start with `AGENT_HANDOFF.md`, then implement and validate Gate 0 before moving to Gate 1.
