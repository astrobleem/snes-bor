#!/usr/bin/env python3
"""Validate the package's locked BOR4086 opcode manifest and Gate 0 fixture."""
from __future__ import annotations
import csv
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = [
    "CONSTSTR", "CONSTDBL", "CONSTINT", "LOAD", "SAVE", "INC", "DEC", "FIELD",
    "CALL", "POS", "NEG", "NOT", "MUL", "DIV", "MOD", "ERR", "ADD", "SUB",
    "SHL", "SHR", "JUMP", "PJUMP", "GE", "LE", "LT", "GT", "EQ", "NE", "OR",
    "AND", "BIT_OR", "XOR", "BIT_AND", "NOOP", "PUSH", "POP", "Branch_FALSE",
    "Branch_TRUE", "Branch_EQUAL", "DATA", "PARAM", "IMMEDIATE", "DEFERRED", "RET",
    "CHECKARG", "CLEAN", "JUMPR", "FUNCDECL",
]

def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")

def main() -> int:
    with (ROOT / "opcode_manifest.csv").open(newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    if len(rows) != 48:
        fail(f"manifest has {len(rows)} rows, expected 48")
    for i, (row, expected_name) in enumerate(zip(rows, EXPECTED)):
        if int(row["value"]) != i:
            fail(f"row {i} has value {row['value']}")
        if row["name"] != expected_name:
            fail(f"opcode {i} is {row['name']!r}, expected {expected_name!r}")
    if rows[7]["name"] != "FIELD" or "fault" not in rows[7]["class"]:
        fail("FIELD must remain the reserved/fault slot")

    fixture = json.loads((ROOT / "tests" / "gate0_program.json").read_text(encoding="utf-8"))
    instructions = fixture["instructions"]
    for ip, ins in enumerate(instructions):
        if ins["ip"] != ip:
            fail(f"Gate 0 instruction index mismatch at row {ip}")
        op = ins["opcode"]
        if not 0 <= op < 48:
            fail(f"Gate 0 opcode out of range at IP {ip}: {op}")
        if EXPECTED[op] != ins["name"]:
            fail(f"Gate 0 opcode/name mismatch at IP {ip}")

    print("OK: 48 opcode values locked; FIELD=7 traps; Gate 0 fixture is internally consistent.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
