# Implementation checklist

## Gate 0

- [ ] Explicitly clear VM IRAM state at cold boot.
- [ ] Establish 16-bit A/X/Y at every VM entry.
- [ ] Validate revision-1 module header and record count.
- [ ] Fetch an eight-byte record without crossing an unvalidated region.
- [ ] Decode opcode/flags/A/B/C.
- [ ] Preserve a short IP/opcode trace.
- [ ] Bounds-check source and destination slot IDs.
- [ ] Implement eight-byte slot copy.
- [ ] Implement signed 32-bit integer ADD.
- [ ] Implement integer EQ -> INTEGER 0/1.
- [ ] Implement Branch_FALSE and JUMP with exactly one IP assignment.
- [ ] Implement ERR fault and root RET -> DONE.
- [ ] Match `tests/gate0_program.json` exactly.
- [ ] Verify BW-RAM guard bytes.
- [ ] Stop; do not combine Gate 1 work into the Gate 0 change.

## Later gates

- [ ] Every ABI value 0..47 has a handler or explicit fault.
- [ ] FIELD=7 faults.
- [ ] Unknown values >=48 fault.
- [ ] Call frames and arg lists are fixed-size and bounds checked.
- [ ] PTR is a typed handle, never a host pointer.
- [ ] Strings have bounded storage and deterministic overflow faults.
- [ ] Numeric profile is stamped and tested.
- [ ] Exact Build 4086 quirks are decided by fixtures, not recollection.
- [ ] Native hot paths retain interpreter fallback.
