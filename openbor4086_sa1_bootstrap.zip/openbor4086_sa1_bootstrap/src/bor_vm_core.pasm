; =============================================================================
; bor_vm_core.pasm
; Poppy-style 65816/SA-1 bootstrap scaffold for the BOR4086 linked-slot VM.
;
; This is an integration scaffold, not a claim of a finished engine. Project-specific
; ROM/BW-RAM bank mapping, SA-1 release, 5A22 mailboxes, and native engine adapters must
; be connected by the implementation agent.
;
; Concatenate src/bor_vm_opcodes.pasm before this file when assembling.
; =============================================================================
.snes

; ---- Project-supplied mapping ------------------------------------------------
; Revision-1 instruction arrays stay within one 64 KiB window.
VM_DEFAULT_CODE_BANK=$C0
VM_DEFAULT_SLOT_BANK=$40
VM_DEFAULT_FRAME_BANK=$41

; ---- Direct-page state -------------------------------------------------------
VM_IP=$00
VM_STATUS=$02
VM_CODE_PTR=$04          ; 24-bit pointer: low16 @ $04, bank byte @ $06
VM_SLOT_PTR=$08          ; 24-bit pointer
VM_OPCODE=$0C            ; byte
VM_RECFLAGS=$0D          ; byte
VM_A=$0E
VM_B=$10
VM_C=$12
VM_TMP0=$14              ; 32-bit
VM_TMP1=$18              ; 32-bit
VM_TMP2=$1C              ; 32-bit
VM_FRAME_TOP=$20
VM_BUDGET=$22
VM_ERROR=$24
VM_ERROR_IP=$26
VM_ERROR_OPCODE=$28      ; byte
VM_RECORD_PTR=$2A        ; 24-bit current record pointer
VM_TRACE_HEAD=$2E        ; byte/word according to final trace implementation
VM_INSTR_COUNT=$30       ; validated instruction count from module header

; ---- Status values -----------------------------------------------------------
VMSTAT_READY=$0001
VMSTAT_RUNNING=$0002
VMSTAT_YIELDED=$0003
VMSTAT_DONE=$0004
VMSTAT_FAULT=$0005

; ---- Deterministic errors ----------------------------------------------------
VMERR_BAD_OPCODE=$0001
VMERR_FIELD_OPCODE=$0002
VMERR_EXPLICIT_ERR=$0003
VMERR_BAD_SLOT=$0004
VMERR_BAD_TYPE=$0005
VMERR_DIV_ZERO=$0006
VMERR_CALL_DEPTH=$0007
VMERR_NO_CALL_FRAME=$0008
VMERR_BAD_CALLSITE=$0009
VMERR_BAD_NATIVE=$000A
VMERR_STRING_POOL=$000B
VMERR_STRING_OVERFLOW=$000C
VMERR_BAD_JUMP=$000D
VMERR_BAD_MODULE=$000E
VMERR_BUDGET_PROTOCOL=$000F
VMERR_UNIMPLEMENTED=$0010

; ---- Generic helper operation IDs -------------------------------------------
VMU_INC=$0000
VMU_DEC=$0001
VMU_POS=$0002
VMU_NEG=$0003
VMU_NOT=$0004

VMB_MUL=$0000
VMB_DIV=$0001
VMB_MOD=$0002
VMB_ADD=$0003
VMB_SUB=$0004
VMB_SHL=$0005
VMB_SHR=$0006
VMB_GE=$0007
VMB_LE=$0008
VMB_LT=$0009
VMB_GT=$000A
VMB_EQ=$000B
VMB_NE=$000C
VMB_OR=$000D
VMB_AND=$000E
VMB_BIT_OR=$000F
VMB_XOR=$0010
VMB_BIT_AND=$0011

; ---- Public entry ------------------------------------------------------------
; Caller has already validated/loaded a module and populated VM_CODE_PTR,
; VM_SLOT_PTR, VM_IP, and VM_BUDGET.
;
; Every external entry explicitly establishes native mode and 16-bit A/X/Y.
vm_run_entry:
    clc
    xce
    rep #$30
    lda #VMSTAT_RUNNING
    sta VM_STATUS
    jmp vm_run

; ---- Interpreter loop --------------------------------------------------------
vm_run:
    rep #$30
    lda VM_BUDGET
    beq vm_yield
    dec a
    sta VM_BUDGET

    jsr vm_fetch_record
    bcs vm_fault_from_a
    jsr vm_trace_record

    sep #$20
    lda VM_OPCODE
    rep #$20
    and #$00FF
    cmp #BOR_OPCODE_END
    bcs vm_dispatch_bad
    jmp vm_dispatch_00

; vm_fetch_record
;   Input:  VM_IP, VM_CODE_PTR, VM_INSTR_COUNT
;   Output: VM_OPCODE/FLAGS/A/B/C and VM_RECORD_PTR
;   Carry:  clear success, set failure with A=error
;
; Revision 1 limits a module to 8192 records, so IP*8 fits 16 bits.
vm_fetch_record:
    rep #$30
    lda VM_IP
    cmp VM_INSTR_COUNT
    bcs vm_fetch_bad
    cmp #$2000
    bcs vm_fetch_bad
    asl a
    asl a
    asl a
    tay

    lda VM_CODE_PTR
    sta VM_RECORD_PTR
    sep #$20
    lda VM_CODE_PTR+2
    sta VM_RECORD_PTR+2

    lda [VM_CODE_PTR],y
    sta VM_OPCODE
    iny
    lda [VM_CODE_PTR],y
    sta VM_RECFLAGS
    rep #$20
    iny
    lda [VM_CODE_PTR],y
    sta VM_A
    iny
    iny
    lda [VM_CODE_PTR],y
    sta VM_B
    iny
    iny
    lda [VM_CODE_PTR],y
    sta VM_C
    clc
    rts
vm_fetch_bad:
    lda #VMERR_BAD_JUMP
    sec
    rts

; Replace this stub with a bounded ring of (IP, opcode) records in IRAM or BW-RAM.
vm_trace_record:
    rts

; ---- Explicit dispatcher -----------------------------------------------------
vm_dispatch_00:
    cmp #$0000
    bne vm_dispatch_01
    jmp vm_op_conststr
vm_dispatch_01:
    cmp #$0001
    bne vm_dispatch_02
    jmp vm_op_constdbl
vm_dispatch_02:
    cmp #$0002
    bne vm_dispatch_03
    jmp vm_op_constint
vm_dispatch_03:
    cmp #$0003
    bne vm_dispatch_04
    jmp vm_op_load
vm_dispatch_04:
    cmp #$0004
    bne vm_dispatch_05
    jmp vm_op_save
vm_dispatch_05:
    cmp #$0005
    bne vm_dispatch_06
    jmp vm_op_inc
vm_dispatch_06:
    cmp #$0006
    bne vm_dispatch_07
    jmp vm_op_dec
vm_dispatch_07:
    cmp #$0007
    bne vm_dispatch_08
    jmp vm_op_field
vm_dispatch_08:
    cmp #$0008
    bne vm_dispatch_09
    jmp vm_op_call
vm_dispatch_09:
    cmp #$0009
    bne vm_dispatch_10
    jmp vm_op_pos
vm_dispatch_10:
    cmp #$000A
    bne vm_dispatch_11
    jmp vm_op_neg
vm_dispatch_11:
    cmp #$000B
    bne vm_dispatch_12
    jmp vm_op_not
vm_dispatch_12:
    cmp #$000C
    bne vm_dispatch_13
    jmp vm_op_mul
vm_dispatch_13:
    cmp #$000D
    bne vm_dispatch_14
    jmp vm_op_div
vm_dispatch_14:
    cmp #$000E
    bne vm_dispatch_15
    jmp vm_op_mod
vm_dispatch_15:
    cmp #$000F
    bne vm_dispatch_16
    jmp vm_op_err
vm_dispatch_16:
    cmp #$0010
    bne vm_dispatch_17
    jmp vm_op_add
vm_dispatch_17:
    cmp #$0011
    bne vm_dispatch_18
    jmp vm_op_sub
vm_dispatch_18:
    cmp #$0012
    bne vm_dispatch_19
    jmp vm_op_shl
vm_dispatch_19:
    cmp #$0013
    bne vm_dispatch_20
    jmp vm_op_shr
vm_dispatch_20:
    cmp #$0014
    bne vm_dispatch_21
    jmp vm_op_jump
vm_dispatch_21:
    cmp #$0015
    bne vm_dispatch_22
    jmp vm_op_pjump
vm_dispatch_22:
    cmp #$0016
    bne vm_dispatch_23
    jmp vm_op_ge
vm_dispatch_23:
    cmp #$0017
    bne vm_dispatch_24
    jmp vm_op_le
vm_dispatch_24:
    cmp #$0018
    bne vm_dispatch_25
    jmp vm_op_lt
vm_dispatch_25:
    cmp #$0019
    bne vm_dispatch_26
    jmp vm_op_gt
vm_dispatch_26:
    cmp #$001A
    bne vm_dispatch_27
    jmp vm_op_eq
vm_dispatch_27:
    cmp #$001B
    bne vm_dispatch_28
    jmp vm_op_ne
vm_dispatch_28:
    cmp #$001C
    bne vm_dispatch_29
    jmp vm_op_or
vm_dispatch_29:
    cmp #$001D
    bne vm_dispatch_30
    jmp vm_op_and
vm_dispatch_30:
    cmp #$001E
    bne vm_dispatch_31
    jmp vm_op_bit_or
vm_dispatch_31:
    cmp #$001F
    bne vm_dispatch_32
    jmp vm_op_xor
vm_dispatch_32:
    cmp #$0020
    bne vm_dispatch_33
    jmp vm_op_bit_and
vm_dispatch_33:
    cmp #$0021
    bne vm_dispatch_34
    jmp vm_op_noop
vm_dispatch_34:
    cmp #$0022
    bne vm_dispatch_35
    jmp vm_op_push
vm_dispatch_35:
    cmp #$0023
    bne vm_dispatch_36
    jmp vm_op_pop
vm_dispatch_36:
    cmp #$0024
    bne vm_dispatch_37
    jmp vm_op_branch_false
vm_dispatch_37:
    cmp #$0025
    bne vm_dispatch_38
    jmp vm_op_branch_true
vm_dispatch_38:
    cmp #$0026
    bne vm_dispatch_39
    jmp vm_op_branch_equal
vm_dispatch_39:
    cmp #$0027
    bne vm_dispatch_40
    jmp vm_op_data
vm_dispatch_40:
    cmp #$0028
    bne vm_dispatch_41
    jmp vm_op_param
vm_dispatch_41:
    cmp #$0029
    bne vm_dispatch_42
    jmp vm_op_immediate
vm_dispatch_42:
    cmp #$002A
    bne vm_dispatch_43
    jmp vm_op_deferred
vm_dispatch_43:
    cmp #$002B
    bne vm_dispatch_44
    jmp vm_op_ret
vm_dispatch_44:
    cmp #$002C
    bne vm_dispatch_45
    jmp vm_op_checkarg
vm_dispatch_45:
    cmp #$002D
    bne vm_dispatch_46
    jmp vm_op_clean
vm_dispatch_46:
    cmp #$002E
    bne vm_dispatch_47
    jmp vm_op_jumpr
vm_dispatch_47:
    cmp #$002F
    bne vm_dispatch_bad
    jmp vm_op_funcdecl
vm_dispatch_bad:
    lda #VMERR_BAD_OPCODE
    jmp vm_raise_fault

; ---- Shared exits -------------------------------------------------------------
vm_next:
    rep #$30
    inc VM_IP
    jmp vm_run

vm_yield:
    lda #VMSTAT_YIELDED
    sta VM_STATUS
    rtl

vm_done:
    lda #VMSTAT_DONE
    sta VM_STATUS
    rtl

vm_fault_from_a:
    ; A already contains deterministic error code.
    jmp vm_raise_fault

vm_raise_fault:
    rep #$30
    sta VM_ERROR
    lda VM_IP
    sta VM_ERROR_IP
    sep #$20
    lda VM_OPCODE
    sta VM_ERROR_OPCODE
    rep #$20
    lda #VMSTAT_FAULT
    sta VM_STATUS
vm_fault:
    rtl

; ---- Runtime no-op/link-marker handlers -------------------------------------
vm_op_conststr:
    jmp vm_next

vm_op_constdbl:
    jmp vm_next

vm_op_constint:
    jmp vm_next

vm_op_noop:
    jmp vm_next

vm_op_push:
    jmp vm_next

vm_op_pop:
    jmp vm_next

vm_op_data:
    jmp vm_next

vm_op_immediate:
    jmp vm_next

vm_op_deferred:
    jmp vm_next

vm_op_checkarg:
    jmp vm_next

vm_op_clean:
    jmp vm_next

vm_op_funcdecl:
    jmp vm_next

; ---- Reserved/error handlers -------------------------------------------------
vm_op_field:
    lda #VMERR_FIELD_OPCODE
    jmp vm_raise_fault

vm_op_err:
    lda #VMERR_EXPLICIT_ERR
    jmp vm_raise_fault

; ---- Slot movement -----------------------------------------------------------
vm_op_load:
    ; A=destination slot, B=source slot
    lda VM_B
    ldx VM_A
    jsr vm_slot_copy_ax       ; contract: source=A, destination=X
    bcs vm_fault_from_a
    jmp vm_next

vm_op_save:
    ; A=destination variable slot, B=source expression slot
    lda VM_B
    ldx VM_A
    jsr vm_slot_copy_ax
    bcs vm_fault_from_a
    jmp vm_next

; ---- Unary operations --------------------------------------------------------
vm_op_inc:
    lda #VMU_INC
    ldx VM_A
    jsr vm_variant_unary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_dec:
    lda #VMU_DEC
    ldx VM_A
    jsr vm_variant_unary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_pos:
    lda #VMU_POS
    ldx VM_A
    jsr vm_variant_unary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_neg:
    lda #VMU_NEG
    ldx VM_A
    jsr vm_variant_unary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_not:
    lda #VMU_NOT
    ldx VM_A
    jsr vm_variant_unary
    bcs vm_fault_from_a
    jmp vm_next

; ---- Binary operations -------------------------------------------------------
vm_op_mul:
    lda #VMB_MUL
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_div:
    lda #VMB_DIV
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_mod:
    lda #VMB_MOD
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_add:
    lda #VMB_ADD
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_sub:
    lda #VMB_SUB
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_shl:
    lda #VMB_SHL
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_shr:
    lda #VMB_SHR
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_ge:
    lda #VMB_GE
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_le:
    lda #VMB_LE
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_lt:
    lda #VMB_LT
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_gt:
    lda #VMB_GT
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_eq:
    lda #VMB_EQ
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_ne:
    lda #VMB_NE
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_or:
    lda #VMB_OR
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_and:
    lda #VMB_AND
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_bit_or:
    lda #VMB_BIT_OR
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_xor:
    lda #VMB_XOR
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

vm_op_bit_and:
    lda #VMB_BIT_AND
    ldx VM_A               ; destination slot
    ldy VM_B               ; left slot; right slot remains in VM_C
    jsr vm_variant_binary
    bcs vm_fault_from_a
    jmp vm_next

; ---- Direct control transfer -------------------------------------------------
vm_op_jump:
vm_op_pjump:
    lda VM_A
    jsr vm_validate_jump_a
    bcs vm_fault_from_a
    sta VM_IP
    jmp vm_run

vm_op_branch_false:
    lda VM_B
    jsr vm_variant_truth_a
    bcs vm_fault_from_a
    cmp #$0000
    bne vm_branch_not_taken
    lda VM_A
    jsr vm_validate_jump_a
    bcs vm_fault_from_a
    sta VM_IP
    jmp vm_run

vm_op_branch_true:
    lda VM_B
    jsr vm_variant_truth_a
    bcs vm_fault_from_a
    cmp #$0000
    beq vm_branch_not_taken
    lda VM_A
    jsr vm_validate_jump_a
    bcs vm_fault_from_a
    sta VM_IP
    jmp vm_run

vm_op_branch_equal:
    lda VM_B
    ldx VM_C
    jsr vm_variant_equal_ax
    bcs vm_fault_from_a
    cmp #$0000
    beq vm_branch_not_taken
    lda VM_A
    jsr vm_validate_jump_a
    bcs vm_fault_from_a
    sta VM_IP
    jmp vm_run

vm_branch_not_taken:
    jmp vm_next

; ---- Calls and returns -------------------------------------------------------
vm_op_call:
    ; A=target ID, B=result slot, C=callsite metadata ID.
    ; vm_call_dispatch performs script/native distinction. For a script call it
    ; sets VM_IP to the callee entry and returns carry clear with A=0. For a native
    ; call it writes the result and leaves VM_IP unchanged, returning A=1.
    jsr vm_call_dispatch
    bcs vm_fault_from_a
    cmp #$0000
    beq vm_run
    jmp vm_next

vm_op_param:
    ; A=destination parameter slot.
    jsr vm_param_copy
    bcs vm_fault_from_a
    jmp vm_next

vm_op_jumpr:
    ; A=epilogue target, B=return-source slot.
    jsr vm_stage_return
    bcs vm_fault_from_a
    lda VM_A
    jsr vm_validate_jump_a
    bcs vm_fault_from_a
    sta VM_IP
    jmp vm_run

vm_op_ret:
    ; A=0: resumed a caller and VM_IP is already assigned.
    ; A=1: root invocation completed.
    jsr vm_return
    bcs vm_fault_from_a
    cmp #$0000
    beq vm_run
    jmp vm_done

; ---- Required helper contracts ----------------------------------------------
; These stubs intentionally fault. Replace one family at a time and keep the
; signatures stable so opcode handlers remain small and reviewable.

; vm_validate_jump_a
;   Input A=target index. Carry clear and A=target when valid.
vm_validate_jump_a:
    cmp #$2000
    bcs vm_validate_jump_bad
    clc
    rts
vm_validate_jump_bad:
    lda #VMERR_BAD_JUMP
    sec
    rts

; vm_slot_copy_ax
;   Input A=source slot ID, X=destination slot ID.
;   Must bounds-check IDs and implement string ownership/refcounts.
vm_slot_copy_ax:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_variant_unary
;   Input A=VMU_* operation, X=operand slot.
vm_variant_unary:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_variant_binary
;   Input A=VMB_* operation, X=destination, Y=left, VM_C=right.
vm_variant_binary:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_variant_truth_a
;   Input A=slot ID. Output A=0/1.
vm_variant_truth_a:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_variant_equal_ax
;   Input A=left slot ID, X=right slot ID. Output A=0/1.
vm_variant_equal_ax:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_call_dispatch
;   Uses VM_A/B/C. Output A=0 script transfer, A=1 native completed.
vm_call_dispatch:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_param_copy
;   Uses VM_A destination and active call frame.
vm_param_copy:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_stage_return
;   Uses VM_B return-source slot and active call frame.
vm_stage_return:
    lda #VMERR_UNIMPLEMENTED
    sec
    rts

; vm_return
;   Output A=0 caller resumed, A=1 root complete.
vm_return:
    ; Gate 0 may implement root-only RET as A=1 before call frames exist.
    lda #$0001
    clc
    rts
