# BOR4086 SA-1 module format, revision 1

All multibyte fields are little-endian. The format contains no host pointers and no
compiler struct dumps.

## 64-byte module header

```text
offset size field
------ ---- ---------------------------------------------------------------
$00    4    magic = "B48S"
$04    1    format_version = 1
$05    1    opcode_abi = 0x30       ; 48 is OPCODE_END sentinel
$06    1    numeric_profile         ; 0=Q16.16/8-byte slot, 1=binary64/12-byte slot
$07    1    flags
$08    2    instruction_count       ; 0..8192 in revision 1
$0A    2    slot_count
$0C    2    callsite_count
$0E    2    native_count
$10    2    entry_main              ; 0xFFFF when absent
$12    2    entry_oncreate
$14    2    entry_ondestroy
$16    2    immediate_count
$18    4    instructions_offset
$1C    4    initial_slots_offset
$20    4    callsites_offset
$24    4    arg_slot_ids_offset
$28    4    strings_offset
$2C    4    natives_offset
$30    4    debug_names_offset       ; zero when stripped
$34    4    module_size
$38    4    crc32 of bytes $40..end
$3C    4    reserved = 0
```

The loader validates magic, version, opcode ABI, numeric profile, module size, CRC,
counts, offsets, alignment, every instruction operand class, and every table range before
setting `VM_STATUS=READY`.

## Instruction records

Eight bytes each:

```text
+0  u8  opcode
+1  u8  flags
+2  u16 operand A
+4  u16 operand B
+6  u16 operand C
```

The operand meanings are authoritative in `opcode_manifest.csv`.

## Initial slot images

### Numeric profile 0: Q16.16

Eight bytes per slot:

```text
+0  u8  type       0 EMPTY, 1 INTEGER, 2 DECIMAL, 5 PTR, 6 STR
+1  u8  flags      bit0 read-only, bit1 dynamic-string, remaining reserved
+2  u16 aux        string length, handle subtype, or zero
+4  u32 value      signed integer, Q16.16, typed handle, or string handle
```

### Numeric profile 1: binary64

Twelve bytes per slot:

```text
+0  u8  type
+1  u8  flags
+2  u16 aux
+4  u64 value
```

INTEGER uses the low 32 bits with required sign extension in the high 32 bits. PTR and
STR use low 32-bit handles. This rule makes malformed slot images detectable.

## Callsite table

Twelve bytes per callsite:

```text
+0  u8  target_kind       0 script, 1 imported-script, 2 native
+1  u8  argc
+2  u16 target_id         instruction index for script; stable ID for native
+4  u16 result_slot       normally agrees with CALL operand B
+6  u16 arg_list_index    index into flat u16 argument-slot table
+8  u16 flags
+A  u16 debug_name_id     0xFFFF when stripped
```

The loader requires `arg_list_index + argc <= arg_slot_id_count` and validates every
argument slot ID.

## Interned strings

The string region begins with:

```text
u16 string_count
u16 offset[string_count + 1]
u8  bytes[]
```

Offsets are relative to `bytes[]`; the final offset is the byte length. Strings are raw
UTF-8/ASCII byte sequences without terminators. Build 4086 scripts are commonly ASCII;
the VM treats bytes opaquely for length, truth, equality, and lexicographic comparison.

A ROM string handle has bit31 clear and indexes this table. A dynamic string handle has
bit31 set and indexes the BW-RAM string-object table.

## Native table

Six bytes per declared native dependency:

```text
+0  u16 stable_native_id
+2  u16 minimum_arity
+4  u16 maximum_arity
```

The cartridge engine has its own generated dispatch table. Module load fails if any
required ID is absent or its declared arity contract is incompatible.

## Normalization rules for the host exporter

1. Preserve opcode numeric values even when records are runtime no-ops.
2. Convert labels/pointers to instruction indices.
3. Normalize every branch target to the actual executable record selected by the old
   linked interpreter's `step`/placeholder skipping behavior.
4. Convert each cached `ScriptVariant*` identity to a slot ID.
5. Preserve the original ordered call argument references.
6. Convert native function pointers to generated stable IDs.
7. Reject `FIELD` records unless building a deliberate negative fixture.
8. Reject unknown opcodes and all values >=48.
9. Emit no raw C struct, pointer, list node, padding byte, or platform enum width.
10. Stamp the numeric profile and include it in the module cache key.
